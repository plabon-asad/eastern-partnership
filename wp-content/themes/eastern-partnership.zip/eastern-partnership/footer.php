
<!-- Partners -->
<footer class="footer">
    <div class="footer-container container">
        <div class="row align-items-center footer-row">
            <div class="col-7 col-md-8 col-xl-9 f-left-col">
                <div class="copyright">© Lorem ipsum 2010 - 2019</div>
            </div>
            <div class="col-5 col-md-4 col-xl-3 f-right-col text-right">
                <ul class="common-ul f-social">
                    <li>
                        <a href="#"><i class="fa fa-facebook"></i></a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>


</div>

<?php
//if (have_posts()) :
//
//    // Start the Loop.
//    while (have_posts()) :
//        the_post();
//        get_template_part('template-parts/post/content', get_post_format());
//
//    endwhile;
//
//else :
//
//    get_template_part('template-parts/post/content', 'none');
//
//endif;
//?>
</body>
</html>